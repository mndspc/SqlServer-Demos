----STORED PROCEDURE--------
--PARAMATER LESS SP--
--AUTHOR:SHOAIB
--DATE:01-OCT-21
CREATE PROCEDURE SELECT_ALL_CUSTOMERS
AS
BEGIN
	SELECT * FROM CUSTOMERS
END
 
---HOW TO CALL PARAM. LESS SP--
EXEC SELECT_ALL_CUSTOMERS
SELECT_ALL_CUSTOMERS

--PARAM. SP-----
--AUTHOR:SHOAIB
--DATE:01-OCT-21
CREATE PROCEDURE ADD_STORES
@store_name varchar(255),
@phone		varchar(25)=NULL,
@email		varchar(255)=NULL,
@street		varchar(255)=NULL,
@city		varchar(255)=NULL,
@state		varchar(10)=NULL,
@zip_code	varchar(5)=NULL
AS
BEGIN
	INSERT INTO STORES(store_name,phone,email,street,city,state,zip_code) 
	VALUES(@store_name,@phone,@email,@street,@city,@state,@zip_code)
	
END

--CALL PARAM. SP----
 ADD_STORES @store_name='STORE-1',@phone='022-22323',@email='store1@gmail.com',@street='M.G.ROAD',@city='PUNE',@state='MAHARASHTRA',@zip_code='422011'
 
 SELECT * FROM STORES
 ---ALTER SP---
 ALTER PROCEDURE ADD_STORES
@store_name varchar(255),
@phone		varchar(25)=NULL,
@email		varchar(255)=NULL,
@street		varchar(255)=NULL,
@city		varchar(255)=NULL,
@state		varchar(10)=NULL,
@zip_code	varchar(5)=NULL
AS
BEGIN
	INSERT INTO STORES(store_name,phone,email,street,city,state,zip_code) 
	VALUES(@store_name,@phone,@email,@street,@city,@state,@zip_code)
	
	SELECT * FROM STORES
END

--CALL AFTER ALTER--
 ADD_STORES @store_name='STORE-2',@phone='022-45646',@email='store2@gmail.com',@street='tilak ROAD',@city='PUNE',@state='MAHARASHTRA',@zip_code='422011'

---SP TO DELETE ROW---
CREATE PROCEDURE DELETE_STORE
@store_id int
AS
BEGIN
	DELETE FROM STORES WHERE STORE_ID=@STORE_ID
END
--CALL SP TO DELETE STORE----
 DELETE_STORE @STORE_ID=4
 DELETE_STORE 5
 
 ----DROP SP---
 DROP  DELETE_STORE