USE AUTOMOTIVEDB
--HOW TO CREATE TABLES
CREATE TABLE categories(
category_id		int			PRIMARY KEY,
category_name	nvarchar(50)NOT NULL
)

CREATE TABLE brands(
brand_id	int			PRIMARY KEY,
brand_name	varchar(50)	NOT NULL
)

CREATE TABLE products(
product_id		int	IDENTITY(100,1) PRIMARY KEY,
product_name	nvarchar(50)		NOT NULL,
brand_id		int					NOT NULL,
category_id		int					NOT NULL,
list_price		numeric(10,2)		NOT NULL,
FOREIGN KEY(brand_id) REFERENCES brands(brand_id) ON DELETE CASCADE,
FOREIGN KEY(category_id)REFERENCES categories(category_id)	ON DELETE CASCADE
)

CREATE TABLE customers(
customer_id	int IDENTITY(1,1)		PRIMARY KEY,
first_name	nvarchar(50)			NOT NULL,
last_name	nvarchar(50)			NOT NULL,
name		as(first_name+' '+last_name),
email		nvarchar(100)			UNIQUE,
zipcode		int						CHECK(zipcode>0)NOT NULL	
)

CREATE TABLE order_details(
order_id	int				PRIMARY KEY,
product_id	int				NOT NULL,
price		numeric(10,2)	NOT NULL,
qty			int				NOT NULL,
total		as(price*qty),
FOREIGN KEY(product_id) REFERENCES products(product_id)ON DELETE CASCADE
)

--DROP A TABLE
DROP TABLE PRODUCTS

--ALTER TABLE
ALTER TABLE products
ADD pro_description	nvarchar(30) NULL

ALTER TABLE products
ALTER COLUMN pro_description nvarchar(50) NULL

ALTER TABLE products
DROP COLUMN pro_description