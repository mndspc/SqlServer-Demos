USE AUTOMOTIVEDB
---INSERT INTO---
INSERT INTO categories VALUES(1,'External Access.')

SELECT * FROM categories

INSERT INTO brands VALUES(100,'Steelbird')
SELECT * FROM brands

INSERT INTO PRODUCTS(product_name,brand_id,category_id,list_price) VALUES('Helmate',100,1,700)
SELECT * FROM PRODUCTS

INSERT INTO CUSTOMERS(first_name,last_name,email,zipcode)VALUES
('adam','jhones','adam@gmail.com',422011),
('marry','jhones','marry@gmail.com',422010)

SELECT * FROM CUSTOMERS
--DELETE----------
DELETE FROM CUSTOMERS
DELETE FROM CUSTOMERS WHERE customer_id=9
DELETE FROM CUSTOMERS WHERE customer_id=9 or first_name='adam'
DELETE FROM CUSTOMERS WHERE customer_id=11 and first_name='adam'

--UPDATE SET----
UPDATE CUSTOMERS SET email='marry123@gmail.com' WHERE customer_id=12
UPDATE CUSTOMERS SET first_name='marry123',last_name='donis',email='marry123@gmail.com',zipcode=331002 WHERE customer_id=12